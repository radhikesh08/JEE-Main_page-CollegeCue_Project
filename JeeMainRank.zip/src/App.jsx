
import JeeRank from './JeeRank/JeeRank'

function App() {
 
  return (
    <>
     <JeeRank/> 
    </>
  )
}

export default App
