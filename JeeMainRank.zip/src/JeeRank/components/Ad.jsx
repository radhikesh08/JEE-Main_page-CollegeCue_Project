import React from 'react'
import img from "../../assets/ad.png"

export default function Ad() {
  return (
    <>
    <img src={img} alt="" srcset="" />
    </>
  )
}
